#include <linux/module.h> 
#include <linux/kernel.h> 
#include <linux/init.h>   

static int __init Initialize(void)
{
    printk(KERN_INFO "Hello world!\n");
    printk(KERN_INFO "Trying to print other texts too\n");
    printk(KERN_INFO "The next program will have more lines\n");
    return 0;   
}

static void __exit Cleanup(void)
{
    printk(KERN_INFO "Exit Module!.\n");
}

module_init(Initialize);
module_exit(Cleanup);
